package com.example.portillo.nextword;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.support.annotation.Nullable;

public class BaseDatos extends SQLiteOpenHelper {

    public  BaseDatos(Context context){
        super(context, "base_de_datos", null, 1);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL("CREATE TABLE Preguntas ("+"_id INTEGER PRIMARY KEY, Pregunta TEXT, Respuesta TEXT, Letra CHARACTER)");
        db.execSQL("CREATE TABLE Puntuaciones ("+"_id INTEGER PRIMARY KEY , Nombre TEXT, Puntos INTEGER, Tiempo INTEGER, Aciertos INTEGER, Errores INTEGER, Letra CHARACTER)");

    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("CREATE TABLE Preguntas ("+"_id INTEGER PRIMARY KEY , Pregunta TEXT, Respuesta TEXT, Letra CHARACTER)");
        db.execSQL("CREATE TABLE Puntuaciones ("+"_id INTEGER PRIMARY KEY , Nombre TEXT, Puntos INTEGER, Tiempo INTEGER, Aciertos INTEGER, Errores INTEGER, Letra CHARACTER)");
    }

    public void insertarPreguntas (){
        SQLiteDatabase db = getWritableDatabase();
        db.execSQL("INSERT INTO Preguntas VALUES" +
                "(1, "+"'Con la A. Nombre de la hija del presidente de los Estados Unidos en Resident Evil 4', "+"'Ashley', "+" 'A')," +
                "(2, "+"'Con la B. Nombre del juego donde el jugador tiene que recolectar notas muciscales', "+"'Banjo Kazooie',"+"'B')," +
                "(3, "+"'Con la C. Es uno de los pokemon iniciales en la región de Kanto.',"+"'Charmander',"+"'C')," +
                "(4, "+"'Con la D. Nombre del villano en la saga de videojuegos Sonic.',"+"'Doctor Eggman',"+"'D')," +
                "(5, "+"'Con la E. Nombre femenino de uno de los personajes principales del videojuego Uncharted.',"+"'Elena Fisher',"+"'E')," +
                "(6, "+"'Con la F. En el videojuego Pokemon GO, solo puedes atraparlo si estás en Japón.',"+"'Farfetchd',"+"'F')," +
                "(7, "+"'Con la G. Es un videojuego de disparos en tercera persona, desarrolado por Epic Games solo para XBOX360.',"+"'Gears of war',"+"'G')," +
                "(8, "+"'Con la H. La trama de este videojuego gira en torno a un hombre llamado Agente 47.',"+"'Hitman',"+"'H')," +
                "(9, "+"'Contiene la I. Nombre del villano principal en FinalFAntasy VII,',"+"'Sefirot',"+"'I')," +
                "(10, "+"'Con la J. Nombre de la saga de videojuegos de baile creada por Ubisoft.',"+"'Just dance',"+"'J')," +
                "(11, "+"'Contiene la K. Nombre del protagonista de The Legend of Zelda',"+"'Link','K')," +
                "(12, "+"'Con la L. Nombre de la protagonista principal en la saga de videojuegos Tomb Raider',"+"'Lara Croft',"+"'L')," +
                "(13, "+"'Con la M. Es uno de los personajes más queridos por los jugadores cuyo creador es Shigeru Miyamoto.',"+"'Mario',"+"'M')," +
                "(14, "+"'Contiene la N. Nombre del protagonista de la saga Devil May Cry.',"+"'Dante',"+"'N')," +
                "(15, "+"'Con la O. Nombre del juego de fútbol basado en una de las series japonesas más vistas y que salió en PS2.',"+"'Oliver y Benji',"+"'O')," +
                "(16, "+"'Con la P. Nombre de una de las princesas de Nintendo.',"+"'Peach',"+"'P')," +
                "(17, "+"'Con la Q. Serie de videojuegos de disparos en primera persona desarrollado por Id Software',"+"'Quake',"+"'Q')," +
                "(18, "+"'Contiene la R. Saga de juegos creada por Naughty Dog para Playstation.', "+"'Crash Bandicoot', "+"'R')," +
                "(19, "+"'Con la S. Nombre del protagonista de Kingdom Hearts.',"+"'Sora',"+"'S')," +
                "(20, "+"'Con la T. El juego transcurre entre dos mundos paralelos, llamados Sylvarant y tethealla.',"+"'Tales of Symphonia',"+"'T')," +
                "(21, "+"'Contiene la U. Nombre del personaje más querido de la saga Street Fighter.',"+"'Ryu',"+"'U')," +
                "(22, "+"'Con la V. Nombre del famoso juego de tenis creado por Sega.', "+"'Virtua Tennis',"+"'V')," +
                "(23, "+"'Con la W. Nombre del lider de Star Wolf en el juego Star Fox.',"+"'Wolf',"+"'W')," +
                "(24, "+"'Con la X. Juego de la saga Dragon Ball.',"+"'Xenoverse',"+"'X')," +
                "(25, "+"'Con la Y. Dinosaurio de la saga Mario.',"+"'Yoshi',"+"'Y')," +
                "(26, "+"'Contiene la Z. Es uno de los protagonistas de la saga Assassins Creed.',"+"'Ezio',"+"'Z')");
    }

    public void borrarPreguntas (){
        SQLiteDatabase db = getWritableDatabase();
        db.execSQL("DELETE FROM Preguntas");
        db.execSQL("update sqlite_sequence set seq=0 where name='Preguntas'");
    }
}