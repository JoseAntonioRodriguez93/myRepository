package com.example.nextword;

import android.animation.ObjectAnimator;
import android.annotation.SuppressLint;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.Color;
import android.hardware.Camera;
import android.os.AsyncTask;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.support.annotation.RequiresApi;
import android.support.constraint.ConstraintLayout;
import android.support.v7.app.AppCompatActivity;
import android.util.DisplayMetrics;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.TextView;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

/**
 * clase de la pantalla de juego
 */
public class juego extends AppCompatActivity {

    //region variables

    //creación de variables y objetos
    android.hardware.Camera camara;
    MostrarCamara mostrarCamara;
    FrameLayout frameLayout;
    char[] letras = new char[26];
    int[] numeros = new int[letras.length];
    char[] respuestas = new char[letras.length];
    ConstraintLayout fondo;
    TextView cronometro;
    TextView fallos;
    TextView aciertos;
    TextView[] rosco = new TextView[letras.length];
    TextView preguntas;
    EditText respuesta;
    Button next;
    Button send;
    private int segundos;
    int contador_aciertos;
    int contador_fallos;
    int posicion;
    boolean fin;
    boolean atras;
    DisplayMetrics medidas;
    ImageView transparencia;
    Handler handler;
    Runnable runnable_ocultar_rosco;
    Runnable runnable_ocultar;
    ImageView arriba;
    ImageView abajo;

    //endregion


    //region onCreate
    @SuppressLint("SetTextI18n")
    @Override
    protected void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_juego);

        inicializaciones();

        //incrustamos la cámara en el framelayout
        frameLayout.addView(mostrarCamara);

        //giramos el ángulo de la cámara 90º para que se ponga vertical
        camara.setDisplayOrientation(90);

        //obtenemos las medidas de la pantalla del dispositivo
        getWindowManager().getDefaultDisplay().getMetrics(medidas);

        //lanzamos el hilo para que se muestre el rosco justo al terminar la animación de abrir la cámara
        handler.postDelayed(runnable_ocultar_rosco, 1400);

        animacionAbrirCamara();

        preguntasAleatorias();

        obtenerPrimeraPregunta();

        new ClaseCronometro().execute();

        aciertos.setText("Aciertos: "+contador_aciertos);
        fallos.setText("Fallos: "+contador_fallos);

    }
    //endregion


    //region metodos

    /**
     * método de la animación que simula la apertura de la cámara
     */
    private void animacionAbrirCamara(){
        //creamos animación que mueve una imágen negra hacia arriba
        ObjectAnimator animacion_arriba = ObjectAnimator.ofFloat(arriba,"translationY", 0, -medidas.heightPixels);
        animacion_arriba.setDuration(2000).start();

        //creamos animación que mueve una imágen negra hacia abajo
        ObjectAnimator animacion_abajo = ObjectAnimator.ofFloat(abajo,"translationY", 0, +medidas.heightPixels);
        animacion_abajo.setDuration(2000).start();
    }

    /**
     * genera la formula del sistema de puntuacion (cada acierto suma 43 puntos y resta el tiempo)
     * @return puntuacion
     */
    private int generarPuntuacion(){
        int puntuacion;
        puntuacion = (contador_aciertos * 43) - Integer.parseInt(cronometro.getText().toString());
        if(puntuacion < 0) {
            puntuacion = 0;
        }

        return puntuacion;
    }

    /**
     * genera un numero aleatorio del 0 al 2
     * @return numero_aleatorio
     */
    private int aleatorio(){
        int numero_aleatorio;
        numero_aleatorio = (int) (Math.random()* 3);
        return numero_aleatorio;
    }

    /**
     * asigna a cada posición de la pregunta un número aleatorio
     */
    private void preguntasAleatorias(){
        for (int i = 0; i < letras.length; i++) {
            numeros[i] = aleatorio();
        }
    }

    /**
     * inicializa todas las variables que vamos a usar
     */
    private void inicializaciones(){

        fondo = findViewById(R.id.fondo);
        respuesta = findViewById(R.id.respuesta);
        frameLayout  = findViewById(R.id.frameLayout);
        camara = Camera.open(Camera.CameraInfo.CAMERA_FACING_FRONT);
        segundos = 0;
        atras = false;
        aciertos = findViewById(R.id.aciertos);
        fallos = findViewById(R.id.fallos);
        cronometro = findViewById(R.id.temporizador);
        preguntas = findViewById(R.id.pregunta);
        next = findViewById(R.id.siguiente);
        send = findViewById(R.id.enviar);
        mostrarCamara = new MostrarCamara(this, camara);

        //obtenemos las medidas de la pantalla
        medidas = new DisplayMetrics();
        transparencia = findViewById(R.id.transparencia);
        arriba = findViewById(R.id.arriba);
        abajo = findViewById(R.id.abajo);
        handler = new Handler();

        //creamos un hilo para volver invisible la imágen despues del tiempo que se le indique
        runnable_ocultar = new Runnable() {
            @Override
            public void run() {
                transparencia.setVisibility(View.INVISIBLE);
            }
        };

        //creamos hilo para retrasar la creación del rosco hasta que pase la animación de apertura de la cámara
        runnable_ocultar_rosco = new Runnable() {
            @Override
            public void run() {
                generarRosco();
            }
        };
    }

    /**
     * método que genera el rosco con un bucle e inserta en cada letra un fondo azul
     */
    private void generarRosco(){
        int angulo = 0;
        float incremento_angulo = 360/25f;
        int radio = Math.round(medidas.widthPixels/2.1f);

        //bucle que genera el rosco, y colorea el fondo de las letras de azul
        for (int i = 0; i < letras.length; i++) {
            letras[i]= (char) ('A'+ i);
            rosco[i]= new TextView(this);
            ConstraintLayout.LayoutParams parametros = new ConstraintLayout.LayoutParams(50,50);
            parametros.circleConstraint = R.id.centro;
            parametros.circleAngle = angulo;
            angulo += incremento_angulo;
            parametros.circleRadius = radio;
            rosco[i].setLayoutParams(parametros);
            rosco[i].setBackground(getDrawable(R.drawable.circulos_azules));
            fondo.addView(rosco[i]);
            rosco[i].setText(((Character)letras[i]).toString());
            rosco[i].setTextColor( Color.WHITE);
            rosco[i].setTextAlignment(View.TEXT_ALIGNMENT_CENTER );
        }

        //se rellena de O el array, lo cual representa que las letras no están respondidas
        for (int i = 0; i < letras.length ; i++) {
            respuestas[i] = 'O';
        }
    }

    /**
     * obtiene la primera pregunta aleatoria correspondiente a la letra A para que aparezca en la aplicación desde el principio
     */
    private void obtenerPrimeraPregunta(){
        DatabaseReference dbreference = FirebaseDatabase.getInstance().getReference().child("Letras").child("A").child(""+numeros[0]).child("pregunta");

        dbreference.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {
                preguntas.setText(dataSnapshot.getValue().toString());
            }

            @Override
            public void onCancelled(DatabaseError databaseError) {
                System.out.println("The read failed: " + databaseError.getCode());
            }});
    }
    //endregion


    //region botones y controles
    /**
     * al pulsar en el botón de atrás, cierra la aplicación
     */
    @Override
    public void onBackPressed() {
        atras = true;
        finish();
    }

    /**
     * al pulsar sobre el botón next
     * @param v view
     */
    public void nextOnClick(View v){
        next();
    }

    /**
     * al pulsar sobre el botón send
     * @param v view
     */
    public void sendOnClick(View v){
        send();
    }
    //endregion


    //region metodos de los botones
    /**
     * método que se ejecuta al pulsar sobre el botón next
     */
    private void next(){
        respuesta.setText("");

        //si todas las preguntas están contestadas, crea un dialog que te manda a la siguiente activity
        if (contador_aciertos + contador_fallos > 25){

            //se bloquean los controles para no poder seguir dandole a los botones
            send.setEnabled(false);
            next.setEnabled(false);
            fin = true;

            //creamos un dialog y pasamos las estadisticas a la otra activity
            AlertDialog.Builder builder = new AlertDialog.Builder(this);
            builder.setMessage("¡Enhorabuena! Has terminado la partida.")
                    .setPositiveButton("Continuar", new DialogInterface.OnClickListener() {
                        public void onClick(DialogInterface dialog, int id) {
                            Intent intent = new Intent(juego.this, Estadisticas.class);
                            //pasamos las estadisticas a la otra activity
                            intent.putExtra("aciertos", contador_aciertos);
                            intent.putExtra("fallos", contador_fallos);
                            intent.putExtra("tiempo", cronometro.getText().toString());
                            intent.putExtra("puntuacion", generarPuntuacion());
                            startActivityForResult(intent, 0);
                            finish();

                        }
                    });
            builder.create();
            builder.setCancelable(false);
            builder.show();
        }

        //se controlan las posiciones para que no se salga del array
        int posicioncontestada;
        if (posicion == 25){
            posicioncontestada = 0;
            posicion = 0;
        }
        else{
            posicioncontestada = 1;
        }

        //avanza hasta encontrar la siguiente letra sin responder
        while(respuestas[posicion+posicioncontestada] != 'O' && !fin){
            posicioncontestada++;
            if (posicion+posicioncontestada == 26){
                posicion = -posicioncontestada;
            }
        }
        posicion +=posicioncontestada;

        //obtenemos las preguntas de la base de datos Firebase en función de su posición
        DatabaseReference dbreference = FirebaseDatabase.getInstance().getReference().child("Letras").child(""+letras[posicion]).child(""+numeros[posicion]).child("pregunta");
        dbreference.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {
                //introducimos las preguntas en un textview
                TextView preguntas = (findViewById(R.id.pregunta));
                preguntas.setText(dataSnapshot.getValue().toString());
                next.setEnabled(true);
                send.setEnabled(true);
            }

            @Override
            public void onCancelled(DatabaseError databaseError) {
                System.out.println("The read failed: " + databaseError.getCode());
            }});
    }


    private void send(){
        DatabaseReference dbreference = FirebaseDatabase.getInstance().getReference().child("Letras").child(""+letras[posicion]).child(""+numeros[posicion]).child("respuesta");
        dbreference.addValueEventListener(new ValueEventListener() {
            @SuppressLint("SetTextI18n")
            @RequiresApi(api = Build.VERSION_CODES.LOLLIPOP)
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {

                if (respuesta.getText().toString().toLowerCase().equals(dataSnapshot.getValue().toString().toLowerCase())){
                    //"v" representa acierto
                    respuestas[posicion]= 'V';
                    contador_aciertos++;
                    //ponemos la imagen visible y en color verde
                    transparencia.setVisibility(View.VISIBLE);
                    transparencia.setImageResource(R.color.verde);
                    aciertos.setText("Aciertos: "+contador_aciertos);
                    rosco[posicion].setBackground(getDrawable(R.drawable.circulos_verdes));
                }
                else {
                    //"x" representa fallo
                    respuestas[posicion]= 'X';
                    contador_fallos++;
                    //ponemos la imagen de fondo visible y en color rojo
                    transparencia.setVisibility(View.VISIBLE);
                    transparencia.setImageResource(R.color.rojo);
                    fallos.setText("Fallos: "+contador_fallos);
                    rosco[posicion].setBackground(getDrawable(R.drawable.circulos_rojos));
                }

                //llamamos al hilo y hacemos que se ponga invisible tras 0.5 segundos
                handler.postDelayed(runnable_ocultar, 250);
                next();

            }

            @Override
            public void onCancelled(DatabaseError databaseError) {
                System.out.println("The read failed: " + databaseError.getCode());
            }});
    }

    //endregion


    //region claseCronometro
    private class ClaseCronometro extends AsyncTask<String, Integer, String> {

        //se para el cronometro cuando el numero de respuestas es igual al de letras
        @Override
        protected String doInBackground(String... strings) {
            while (contador_aciertos + contador_fallos < 26 && !atras) {
                try {
                    Thread.sleep(1000);
                    segundos++;
                    publishProgress(segundos);

                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
            }
            isCancelled();
            return "Terminado";
        }

        //actualiza el tiempo en un textview y lo muestra
        @Override
        protected void onProgressUpdate(Integer... values) {
            String tiempo = Integer.toString(segundos);
            cronometro.setText(tiempo);
        }
    }
    //endregion
}


