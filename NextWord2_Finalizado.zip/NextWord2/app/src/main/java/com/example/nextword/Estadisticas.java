package com.example.nextword;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

import java.util.Objects;

public class Estadisticas extends AppCompatActivity {

    //region variables

    TextView tiempo;
    TextView aciertos;
    TextView fallos;
    TextView puntos;
    Button inicio;
    Button puntuaciones;
    EditText usuario;


    //endregion


    //region onCreate

    @SuppressLint("SetTextI18n")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_estadisticas);

        inicializaciones();

        //escribimos en los textviews lo que obtenemos de la otra activity
        tiempo.setText(tiempo.getText().toString()+ Objects.requireNonNull(getIntent().getExtras()).getString("tiempo"));
        aciertos.setText(aciertos.getText().toString()+getIntent().getExtras().getInt("aciertos"));
        fallos.setText(fallos.getText().toString()+getIntent().getExtras().getInt("fallos"));
        puntos.setText(puntos.getText().toString()+getIntent().getExtras().getInt("puntuacion"));


    }

    //endregion


    //region metodos

    /**
     * inicializamos los componentes
     */
    private void inicializaciones(){
        tiempo = findViewById(R.id.estadisticas_tiempo);
        aciertos = findViewById(R.id.estadisticas_aciertos);
        fallos = findViewById(R.id.estadisticas_fallos);
        puntos = findViewById(R.id.estadisticas_puntuacion);
        usuario = findViewById(R.id.usuario);

        inicio = findViewById(R.id.inicio);
        puntuaciones = findViewById(R.id.puntuaciones);
    }

    /**
     * método que sube las estadisticas del usuario a Firebase
     */
    private void subirEstadisticas(){
        DatabaseReference dbreference = FirebaseDatabase.getInstance().getReference().child("Usuarios").push();

        dbreference.child("nombre").setValue(usuario.getText().toString());
        dbreference.child("tiempo").setValue(tiempo.getText());
        dbreference.child("aciertos").setValue(aciertos.getText());
        dbreference.child("fallos").setValue(fallos.getText());
        dbreference.child("puntuacion").setValue(Integer.parseInt(puntos.getText().toString()));

        Toast toast1 = Toast.makeText(getApplicationContext(),"Se han subido tus estadísticas.", Toast.LENGTH_SHORT);

        toast1.show();
    }

    //endregion


    //region botones y controles
    /**
     * al pulsar en el botón de atrás, cierra la aplicación
     */
    @Override
    public void onBackPressed() {
        finish();
    }

    /**
     * botón que lleva a la pantalla de inicio
     * @param v
     */
    public void inicioOnClick(View v){
        inicio();
    }



    /**
     * botón que lleva a la pantalla de puntuaciones
     * @param v
     */
    public void puntuacionesOnClick(View v){
        puntuaciones();
    }
    //endregion


    //region métodos de los botones

    /**
     * método que lleva a la pantalla de inicio
     */
    public void inicio(){
        if (!usuario.getText().toString().equals("")){
            subirEstadisticas();
        }

        Intent intent = new Intent(Estadisticas.this, Inicio.class);
        startActivityForResult(intent, 0);
        finish();
    }

    /**
     * método que lleva a la pantalla de puntuaciones
     */
    public void puntuaciones(){
        if (!usuario.getText().toString().equals("")){
            subirEstadisticas();
        }

        Intent intent = new Intent(Estadisticas.this, Leaderboard.class);
        startActivityForResult(intent, 0);
        finish();
    }

    //endregion
}
