package com.example.nextword;

import android.annotation.SuppressLint;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.TextView;

import java.util.Objects;

public class Estadisticas extends AppCompatActivity {

    //region variables
    TextView tiempo;
    TextView aciertos;
    TextView fallos;
    TextView puntos;
    //endregion

    @SuppressLint("SetTextI18n")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_estadisticas);

        inicializaciones();

        tiempo.setText(tiempo.getText().toString()+ Objects.requireNonNull(getIntent().getExtras()).getString("tiempo"));
        aciertos.setText(aciertos.getText().toString()+getIntent().getExtras().getInt("aciertos"));
        fallos.setText(fallos.getText().toString()+getIntent().getExtras().getInt("fallos"));
        puntos.setText(puntos.getText().toString()+getIntent().getExtras().getInt("puntuacion"));
    }

    //region metodos

    /**
     * inicializamos los componentes
     */
    private void inicializaciones(){
        tiempo = findViewById(R.id.estadisticas_tiempo);
        aciertos = findViewById(R.id.estadisticas_aciertos);
        fallos = findViewById(R.id.estadisticas_fallos);
        puntos = findViewById(R.id.estadisticas_puntuacion);
    }
    //endregion
}
