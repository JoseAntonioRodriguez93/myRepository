package com.example.portillo.nextword;

import android.Manifest;
import android.content.DialogInterface;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.graphics.Point;
import android.hardware.Camera;
import android.os.Build;
import android.support.constraint.ConstraintLayout;
import android.support.v4.app.ActivityCompat;
import android.support.v4.content.ContextCompat;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.Display;
import android.view.Gravity;
import android.view.ViewGroup;
import android.widget.FrameLayout;
import android.widget.TextView;
import android.widget.Toast;

import org.w3c.dom.Text;

//CLASE QUE EJECUTA LA PANTALLA DE JUEGO
public class juego extends AppCompatActivity {
    android.hardware.Camera camera;
    FrameLayout frameLayout;
    MostrarCamara mostrarCamara;
    private static final int PERMISSION_REQUEST_CODE = 200;

    @Override
    protected void onCreate(Bundle savedInstanceState) {

        //QUITA LA BARRA QUE APARECE CON EL TÍTULO Y EL LOGO DE LA APLICACIÓN
        getSupportActionBar().hide();

        //SE CREA LA ACTIVITY
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_juego);

        //OBTENEMOS EL LARGO Y ALTO DE LA PANTALLA DEL MOVIL
        Display display = getWindowManager().getDefaultDisplay();
        Point size = new Point();
        display.getSize(size);
        int width = size.x;
        int height = size.y;

     /*   //CREAMOS UN OBJETO FONDO, QUE VA A SER EL CONSTRAINT LAYOUT QUE LO CONTIENE TODO
        ConstraintLayout fondo = findViewById(R.id.fondo);

        //GENERAMOS LOS TEXTVIEW A TRAVES DE CODIGO EN LUGAR DE EN EL XML
        TextView txt = new TextView(this);

        txt.setWidth(width);
        txt.setHeight(height/4);

        txt.setBackgroundColor(Color.WHITE);
        fondo.addView(txt);
     */
        //LAYOUT DE LA CAMARA
        FrameLayout ventanaCamara = findViewById(R.id.frameLayout);


        //SI EL USUARIO ACEPTA LOS PERMISOS, LANZA LA CÁMARA
        if (checkPermission()) {
            frameLayout = (FrameLayout)findViewById(R.id.frameLayout);

            //ABRIMOS LA CÁMARA
            camera = Camera.open(Camera.CameraInfo.CAMERA_FACING_FRONT);

            //GIRA LA CÁMARA 90º PARA PONERLA VERTICAL, YA QUE POR DEFECTO APARECE EN HORIZONTAL
            camera.setDisplayOrientation(90);

            //MOSTRAMOS LA CÁMARA
            mostrarCamara = new MostrarCamara(this, camera);
            frameLayout.addView(mostrarCamara);

        } else {
            requestPermission();
        }

    }



    //ESTOS MÉTODOS PIDEN PERMISOS AL SISTEMA PARA PODER USAR LA CÁMARA Y CONTROLAN LOS ERRORES
    private boolean checkPermission() {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA)
                != PackageManager.PERMISSION_GRANTED) {

            return false;
        }
        return true;
    }

    private void requestPermission() {

        ActivityCompat.requestPermissions(this,
                new String[]{Manifest.permission.CAMERA},
                PERMISSION_REQUEST_CODE);
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String permissions[], int[] grantResults) {
        switch (requestCode) {
            case PERMISSION_REQUEST_CODE:
                if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                    Toast.makeText(getApplicationContext(), "Permission Granted", Toast.LENGTH_SHORT).show();
                } else {
                    Toast.makeText(getApplicationContext(), "Permission Denied", Toast.LENGTH_SHORT).show();
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                        if (ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA)
                                != PackageManager.PERMISSION_GRANTED) {
                            showMessageOKCancel("You need to allow access permissions",
                                    new DialogInterface.OnClickListener() {
                                        @Override
                                        public void onClick(DialogInterface dialog, int which) {
                                            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                                                requestPermission();
                                            }
                                        }
                                    });
                        }
                    }
                }
                break;
        }
    }

    private void showMessageOKCancel(String message, DialogInterface.OnClickListener okListener) {
        new AlertDialog.Builder(juego.this)
                .setMessage(message)
                .setPositiveButton("OK", okListener)
                .setNegativeButton("Cancel", null)
                .create()
                .show();
    }
}
