package com.example.nextword;

import android.graphics.Color;
import android.hardware.Camera;
import android.os.Bundle;
import android.support.constraint.ConstraintLayout;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.TextView;

/**
 * clase de la pantalla de juego
 */
public class juego extends AppCompatActivity {

    //creación de variables y objetos
    android.hardware.Camera camara;
    MostrarCamara mostrarCamara;
    FrameLayout frameLayout;
    char[] letras = new char[26];
    char[] respuestas = new char[letras.length];
    ConstraintLayout fondo;
    TextView cronometro;
    TextView fallos;
    TextView aciertos;
    TextView[] rosco;
    EditText respuesta;
    Button next;
    Button send;
    int contador_aciertos;
    int contador_fallos;
    int posicion;
    boolean fin;


    @Override
    protected void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_juego);


        frameLayout  = findViewById(R.id.frameLayout);
        camara = Camera.open(Camera.CameraInfo.CAMERA_FACING_FRONT);
        camara.setDisplayOrientation(90);

        mostrarCamara = new MostrarCamara(this, camara);
        frameLayout.addView(mostrarCamara);

        generarRosco();
    }

    private void generarRosco(){
        int angulo = 0;
        float incremento_angulo = 360/25;
        int radio = 500;

        //bucle que genera el rosco, y colorea el fondo de las letras de azul
        for (int i = 0; i < letras.length; i++) {
            letras[i]= (char) ('A'+ i);
            rosco[i]= new TextView(this);
            ConstraintLayout.LayoutParams parametros = new ConstraintLayout.LayoutParams(50,50);
            parametros.circleConstraint = R.id.centro;
            parametros.circleAngle = angulo;
            angulo += incremento_angulo;
            parametros.circleRadius = radio;
            rosco[i].setLayoutParams(parametros);
            rosco[i].setBackground(getDrawable(R.drawable.circulos_azules));
            fondo.addView(rosco[i]);
            rosco[i].setText(   ((Character)letras[i]).toString()   );
            rosco[i].setTextColor( Color.WHITE);
            rosco[i].setTextAlignment(View.TEXT_ALIGNMENT_CENTER );
        }

        //se rellena de O el array, lo cual representa que las letras no están respondidas
        for (int i = 0; i < letras.length ; i++) {
            respuestas[i] = 'O';
        }
    }


}


