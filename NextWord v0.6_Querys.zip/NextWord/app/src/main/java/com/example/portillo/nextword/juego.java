package com.example.portillo.nextword;

import android.Manifest;
import android.annotation.SuppressLint;
import android.content.DialogInterface;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.hardware.Camera;
import android.os.AsyncTask;
import android.os.Build;
import android.support.annotation.RequiresApi;
import android.support.constraint.ConstraintLayout;
import android.support.v4.app.ActivityCompat;
import android.support.v4.content.ContextCompat;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.Query;
import com.google.firebase.database.ValueEventListener;

//CLASE QUE EJECUTA LA PANTALLA DE JUEGO
public class juego extends AppCompatActivity {
    //--------------------------------------------------------------DECLARACIÓN DE VARIABLES-------------------------------------------------------------------------------
    android.hardware.Camera camera;
    FrameLayout frameLayout;
    MostrarCamara mostrarCamara;
    public char [] letras = new char [26];
    private static final int PERMISSION_REQUEST_CODE = 200;
    boolean acierto;
    int contadorRespuestas = 0;

    //----------------------------------------------------------------------------------------------------------------------------------------------------------------------

    @RequiresApi(api = Build.VERSION_CODES.LOLLIPOP)
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        //----------------------------------------------------------CREACIÓN DE BOTONES Y SUS FUNCIONES-----------------------------------------------------------------------------------

        //QUITA LA BARRA QUE APARECE CON EL TÍTULO Y EL LOGO DE LA APLICACIÓN
        getSupportActionBar().hide();

        //SE CREA LA ACTIVITY
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_juego);

        //CREACION DEL BOTON "NEXT"
        Button btn = (Button) findViewById(R.id.botonNext);
        btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {



            }
        });

        //CREACION DEL BOTON "SEND"
        Button btn2 = (Button) findViewById(R.id.botonSend);
        btn2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
        contadorRespuestas++;



            }
        });


        //------------------------------------------------------------------------GENERACIÓN DEL ROSCO----------------------------------------------------------------------------------------

        //CREAMOS ARRAY Y "FOR" QUE VA A GENERAR LAS LETRAS DEL ROSCO Y LOS TEXTVIEWS
        ConstraintLayout fondo = findViewById(R.id.fondo);
        TextView [] arraytextviews = new TextView[letras.length];
        int angulo = 0;
        float incrementoAngulo = 360/25;
        int radio = 500;

        for (int i = 0; i < letras.length; i++) {
            letras[i]= (char) ('A'+ i);
            arraytextviews[i]= new TextView(this);

            ConstraintLayout.LayoutParams parametros = new ConstraintLayout.LayoutParams(50,50);

            parametros.circleConstraint = R.id.centro;
            parametros.circleAngle = angulo;
            angulo += incrementoAngulo;
            parametros.circleRadius = radio;

            arraytextviews[i].setLayoutParams(parametros);
            arraytextviews[i].setBackground(getDrawable(R.drawable.circulos_azules));
            fondo.addView(arraytextviews[i]);
            arraytextviews[i].setText(   ((Character)letras[i]).toString()   );
            arraytextviews[i].setTextColor( Color.WHITE);
            arraytextviews[i].setTextAlignment(View.TEXT_ALIGNMENT_CENTER );
        }

        //----------------------------------------------------------------------------------------------------------------------------------------------------------------------
        
        //------------------------------------------------------------------------BASE DE DATOS---------------------------------------------------------------------------------
        //HACEMOS REFERENCIA A LA BASE DE DATOS

        DatabaseReference dbreference = FirebaseDatabase.getInstance().getReference().child("Letras").child("A").child("0").child("pregunta");
        dbreference.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {
                TextView preguntas = (findViewById(R.id.textView4));
                preguntas.setText(dataSnapshot.getValue().toString());

                }

            @Override
            public void onCancelled(DatabaseError databaseError) {
                System.out.println("The read failed: " + databaseError.getCode());
            }});


        //----------------------------------------------------------------------------------------------------------------------------------------------------------------------





        //-------------------------------------------------------------------------GENERACIÓN DE LA CÁMARA--------------------------------------------------------------------------

        //LAYOUT DE LA CAMARA
        FrameLayout ventanaCamara = findViewById(R.id.frameLayout);


        //SI EL USUARIO ACEPTA LOS PERMISOS, LANZA LA CÁMARA
        if (checkPermission()) {
            frameLayout = (FrameLayout)findViewById(R.id.frameLayout);

            //ABRIMOS LA CÁMARA
            camera = Camera.open(Camera.CameraInfo.CAMERA_FACING_FRONT);

            //GIRA LA CÁMARA 90º PARA PONERLA VERTICAL, YA QUE POR DEFECTO APARECE EN HORIZONTAL
            camera.setDisplayOrientation(90);

            //MOSTRAMOS LA CÁMARA
            mostrarCamara = new MostrarCamara(this, camera);
            frameLayout.addView(mostrarCamara);

        } else {
            requestPermission();
        }

        //EJECUTA EL CRONÓMETRO
        new ClaseCronometro().execute();
    }

    //-------------------------------------------------------------------------CRONÓMETRO--------------------------------------------------------------------------
    //CREAMOS CLASE INTERNA CRÓNOMETRO
    private class ClaseCronometro extends AsyncTask<String, Integer, String>{

        int segundos = 0;

        //DEFINIMOS LA LÓGICA DEL CRONÓMETRO
        @Override
        protected String doInBackground(String... strings) {
            while (contadorRespuestas < 26) {
                try {
                    Thread.sleep(1000);
                    segundos++;
                    publishProgress(segundos);

                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
            }
            return "Terminado";
        }

        //ACTUALIZA EL PROGRESO DEL CRONÓMETRO EN UN TEXTVIEW
        @Override
        protected void onProgressUpdate(Integer... values) {
            TextView cronometro = (findViewById(R.id.textView2));
            String tiempo = Integer.toString(segundos);
            cronometro.setText(tiempo);

        }

        //MUESTRA EN CONSOLA UN MENSAJE DE TERMINADO
        @Override
        protected void onPostExecute (String s){
            super.onPostExecute(s);
            Log.e("terminado: ", ""+s);
        }
    }

    //-------------------------------------------------------------------------------------------------------------------------------------------------------------

    //ESTOS MÉTODOS PIDEN PERMISOS AL SISTEMA PARA PODER USAR LA CÁMARA Y CONTROLAN LOS ERRORES
    private boolean checkPermission() {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA)
                != PackageManager.PERMISSION_GRANTED) {

            return false;
        }
        return true;
    }

    private void requestPermission() {

        ActivityCompat.requestPermissions(this,
                new String[]{Manifest.permission.CAMERA},
                PERMISSION_REQUEST_CODE);
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String permissions[], int[] grantResults) {
        switch (requestCode) {
            case PERMISSION_REQUEST_CODE:
                if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                    Toast.makeText(getApplicationContext(), "Permission Granted", Toast.LENGTH_SHORT).show();
                } else {
                    Toast.makeText(getApplicationContext(), "Permission Denied", Toast.LENGTH_SHORT).show();
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                        if (ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA)
                                != PackageManager.PERMISSION_GRANTED) {
                            showMessageOKCancel("You need to allow access permissions",
                                    new DialogInterface.OnClickListener() {
                                        @Override
                                        public void onClick(DialogInterface dialog, int which) {
                                            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                                                requestPermission();
                                            }
                                        }
                                    });
                        }
                    }
                }
                break;
        }
    }

    private void showMessageOKCancel(String message, DialogInterface.OnClickListener okListener) {
        new AlertDialog.Builder(juego.this)
                .setMessage(message)
                .setPositiveButton("OK", okListener)
                .setNegativeButton("Cancel", null)
                .create()
                .show();
    }
    //----------------------------------------------------------------------------------------------------------------------------------------------------------------------

}
