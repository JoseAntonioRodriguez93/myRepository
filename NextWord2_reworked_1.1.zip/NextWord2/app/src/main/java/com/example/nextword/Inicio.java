package com.example.nextword;

import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.support.v4.app.ActivityCompat;
import android.support.v4.content.ContextCompat;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

/**
 * clase de la pantalla de inicio
 */
public class Inicio extends AppCompatActivity {

    //creación de variables
    private static final int PERMISSION_REQUEST_CODE = 200;
    Button boton_jugar;

    @Override
    protected void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_inicio);

        //creación del botón de juego
        boton_jugar = findViewById(R.id.button_jugar);

        //pide permisos al usuario para usar la cámara
        requestPermission();
    }

    /**
     * comprueba que los permisos esten activados
     * @return boolean
     */
    private boolean checkPermission() {
        return ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED;
    }


    /**
     * pide permisos al usuario para usar la cámara
     */
    private void requestPermission() {

        ActivityCompat.requestPermissions(this,
                new String[]{Manifest.permission.CAMERA},
                PERMISSION_REQUEST_CODE);
    }

    /**
     * se ejecuta al pulsar el botón de juego
     * @param v
     */
    public void inicioOnClick(View v){

        //si se aceptan los permisos, lanza la activity
        if (checkPermission()) {
            Intent intent = new Intent(Inicio.this, juego.class);
            startActivityForResult(intent, 0);
            finish();
        }
        //si no se aceptan, sigue pidiendolos y no avanza de activity
        else {
            requestPermission();
        }
    }

}
