package com.example.nextword;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.graphics.Color;
import android.hardware.Camera;
import android.os.AsyncTask;
import android.os.Build;
import android.os.Bundle;
import android.support.annotation.RequiresApi;
import android.support.constraint.ConstraintLayout;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.TextView;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

/**
 * clase de la pantalla de juego
 */
public class juego extends AppCompatActivity {

    //creación de variables y objetos
    android.hardware.Camera camara;
    MostrarCamara mostrarCamara;
    FrameLayout frameLayout;
    char[] letras = new char[26];
    char[] respuestas = new char[letras.length];
    ConstraintLayout fondo;
    TextView cronometro;
    TextView fallos;
    TextView aciertos;
    TextView[] rosco = new TextView[letras.length];
    TextView preguntas;
    EditText respuesta;
    Button next;
    Button send;
    private int segundos;
    int contador_aciertos;
    int contador_fallos;
    int posicion;
    boolean fin;
    boolean atras;


    @SuppressLint("SetTextI18n")
    @Override
    protected void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_juego);

        inicializaciones();
        frameLayout.addView(mostrarCamara);
        camara.setDisplayOrientation(90);

        generarRosco();

        obtenerPrimeraPregunta();

        new ClaseCronometro().execute();

        aciertos.setText("Aciertos: "+contador_aciertos);
        fallos.setText("Fallos: "+contador_fallos);


    }

    private void inicializaciones(){

        fondo = findViewById(R.id.fondo);
        respuesta = findViewById(R.id.respuesta);
        frameLayout  = findViewById(R.id.frameLayout);
        camara = Camera.open(Camera.CameraInfo.CAMERA_FACING_FRONT);
        segundos = 0;
        atras = false;
        aciertos = findViewById(R.id.aciertos);
        fallos = findViewById(R.id.fallos);
        cronometro = findViewById(R.id.temporizador);
        preguntas = findViewById(R.id.pregunta);
        next = findViewById(R.id.siguiente);
        send = findViewById(R.id.enviar);
        mostrarCamara = new MostrarCamara(this, camara);
    }

    /**
     * al pulsar en el botón de atrás, cierra la aplicación
     */
    @Override
    public void onBackPressed() {
        atras = true;
        finish();
    }

    /**
     * al pulsar sobre el botón next
     * @param v
     */
    public void nextOnClick(View v){
        next();
    }

    /**
     * al pulsar sobre el botón send
     * @param v
     */
    public void sendOnClick(View v){
        send();
    }

    private void obtenerPrimeraPregunta(){
        DatabaseReference dbreference = FirebaseDatabase.getInstance().getReference().child("Letras").child("A").child("0").child("pregunta");

        dbreference.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {
                preguntas.setText(dataSnapshot.getValue().toString());
            }

            @Override
            public void onCancelled(DatabaseError databaseError) {
                System.out.println("The read failed: " + databaseError.getCode());
            }});
    }

    /**
     * método que se ejecuta al pulsar sobre el botón next
     */
    private void next(){
        respuesta.setText("");

        if (contador_aciertos + contador_fallos > 25){

            //te manda a la siguiente activity
            Intent intent = new Intent(juego.this, Inicio.class);
            startActivityForResult(intent, 0);
            finish();

            fin = true;
        }

        //se controlan las posiciones para que no se salga del array
        int posicioncontestada;
        if (posicion == 25){
            posicioncontestada = 0;
            posicion = 0;
        }
        else{
            posicioncontestada = 1;
        }

        //avanza hasta encontrar la siguiente letra sin responder
        while(respuestas[posicion+posicioncontestada] != 'O' && !fin){
            posicioncontestada++;
            if (posicion+posicioncontestada == 26){
                posicion = -posicioncontestada;
            }
        }
        posicion +=posicioncontestada;

        //obtenemos las preguntas de la base de datos Firebase en función de su posición
        DatabaseReference dbreference = FirebaseDatabase.getInstance().getReference().child("Letras").child(""+letras[posicion]).child("0").child("pregunta");
        dbreference.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {

                //introducimos las preguntas en un textview
                TextView preguntas = (findViewById(R.id.pregunta));
                preguntas.setText(dataSnapshot.getValue().toString());
                next.setEnabled(true);
                send.setEnabled(true);
            }

            @Override
            public void onCancelled(DatabaseError databaseError) {
                System.out.println("The read failed: " + databaseError.getCode());
            }});
    }


    private void send(){
        DatabaseReference dbreference = FirebaseDatabase.getInstance().getReference().child("Letras").child(""+letras[posicion]).child("0").child("respuesta");
        dbreference.addValueEventListener(new ValueEventListener() {
            @SuppressLint("SetTextI18n")
            @RequiresApi(api = Build.VERSION_CODES.LOLLIPOP)
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {

                if (respuesta.getText().toString().toLowerCase().equals(dataSnapshot.getValue().toString().toLowerCase())){
                    respuestas[posicion]= 'V'; //V MAYUSCULA SIGNIFICA ACERTADO
                    aciertos.setText("Aciertos: "+contador_aciertos);
                    rosco[posicion].setBackground(getDrawable(R.drawable.circulos_verdes));
                    contador_aciertos++;
                }
                else {
                    respuestas[posicion]= 'X'; //X MAYUSCULA SIGNIFICA FALLADO
                    fallos.setText("Fallos: "+contador_fallos);
                    rosco[posicion].setBackground(getDrawable(R.drawable.circulos_rojos));
                    contador_fallos++;
                }

                next();

            }

            @Override
            public void onCancelled(DatabaseError databaseError) {
                System.out.println("The read failed: " + databaseError.getCode());
            }});
    }

    private void generarRosco(){
        int angulo = 0;
        float incremento_angulo = 360/25;
        int radio = 500;

        //bucle que genera el rosco, y colorea el fondo de las letras de azul
        for (int i = 0; i < letras.length; i++) {
            letras[i]= (char) ('A'+ i);
            rosco[i]= new TextView(this);
            ConstraintLayout.LayoutParams parametros = new ConstraintLayout.LayoutParams(50,50);
            parametros.circleConstraint = R.id.centro;
            parametros.circleAngle = angulo;
            angulo += incremento_angulo;
            parametros.circleRadius = radio;
            rosco[i].setLayoutParams(parametros);
            rosco[i].setBackground(getDrawable(R.drawable.circulos_azules));
            fondo.addView(rosco[i]);
            rosco[i].setText(   ((Character)letras[i]).toString()   );
            rosco[i].setTextColor( Color.WHITE);
            rosco[i].setTextAlignment(View.TEXT_ALIGNMENT_CENTER );
        }

        //se rellena de O el array, lo cual representa que las letras no están respondidas
        for (int i = 0; i < letras.length ; i++) {
            respuestas[i] = 'O';
        }
    }

    private class ClaseCronometro extends AsyncTask<String, Integer, String> {

        //se para el cronometro cuando el numero de respuestas es igual al de letras
        @Override
        protected String doInBackground(String... strings) {
            while (contador_aciertos + contador_fallos < 26 && !atras) {
                try {
                    Thread.sleep(1000);
                    segundos++;
                    publishProgress(segundos);

                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
            }
            isCancelled();
            return "Terminado";
        }

        //actualiza el tiempo en un textview y lo muestra
        @Override
        protected void onProgressUpdate(Integer... values) {
            String tiempo = Integer.toString(segundos);
            cronometro.setText(tiempo);
        }
    }


}


