package com.example.portillo.nextword;

import android.Manifest;
import android.annotation.SuppressLint;
import android.app.Dialog;
import android.content.DialogInterface;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.hardware.Camera;
import android.os.AsyncTask;
import android.os.Build;
import android.support.annotation.RequiresApi;
import android.support.constraint.ConstraintLayout;
import android.support.v4.app.ActivityCompat;
import android.support.v4.app.DialogFragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.content.ContextCompat;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.Query;
import com.google.firebase.database.ValueEventListener;

//CLASE QUE EJECUTA LA PANTALLA DE JUEGO

/**
 * Clase Juego que ejecuta la pantalla donde aparece el juego.
 */
public class juego extends AppCompatActivity {

//--------------------------------------------------------------DECLARACION DE VARIABLES-------------------------------------------------------------------------------
    android.hardware.Camera camera;
    FrameLayout frameLayout;
    MostrarCamara mostrarCamara;
    public char [] letras = new char [26];
    private static final int PERMISSION_REQUEST_CODE = 200;
    int posicion = 0;
    static int bien = 0;
    static int mal = 0;
    char [] arrayrespondido = new char [letras.length];
    static int segundos = 0;
    //----------------------------------------------------------------------------------------------------------------------------------------------------------------------

    @RequiresApi(api = Build.VERSION_CODES.LOLLIPOP)
    @Override
    protected void onCreate(Bundle savedInstanceState) {

/**
 * QUITA LA BARRA QUE APARECE CON EL TITULO Y EL LOGO DE LA APLICACION
 */

        getSupportActionBar().hide();

        //SE CREA LA ACTIVITY
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_juego);

/**SE CREA UN ARRAY DEL TAMAÑO DE LAS LETRAS Y SE LE ASIGNAN 'O' A CADA POSICION. CADA '0' SIGNIFICA QUE LA POSICION NO ESTA RESPONDIDA ESTO SIRVE PARA HACER QUE EL ROSCO VAYA DANDO VUELTAS EN BUSCA DE LAS LETRAS NO RESPONDIDAS, CREANDO ASI EL EFECTO PASAPALABRA
        */
        for (int i = 0; i < letras.length ; i++) {
            arrayrespondido [i] = 'O'; // LA "O" EN MAYUSCULA REPRESENTA NO CONTESTADO
        }

        //------------------------------------------------------------------------GENERACION DEL ROSCO----------------------------------------------------------------------------------------
/**
 * CREAMOS ARRAY Y QUE VA A GENERAR LAS LETRAS DEL ROSCO Y LOS TEXTVIEWS CON SUS BACKGROUNDS
 */
        ConstraintLayout fondo = findViewById(R.id.fondo);
        final TextView [] arraytextviews = new TextView[letras.length];
        int angulo = 0;
        float incrementoAngulo = 360/25;
        int radio = 500;

        for (int i = 0; i < letras.length; i++) {
            letras[i]= (char) ('A'+ i);
            arraytextviews[i]= new TextView(this);

/**
 *SE DEFINEN LOS PARAMETROS NECESARIOS PARA QUE EL ROSCO QUEDE TAL Y COMO QUEREMOS
 */

            ConstraintLayout.LayoutParams parametros = new ConstraintLayout.LayoutParams(50,50);
            parametros.circleConstraint = R.id.centro;
            parametros.circleAngle = angulo;
            angulo += incrementoAngulo;
            parametros.circleRadius = radio;

            arraytextviews[i].setLayoutParams(parametros);
            arraytextviews[i].setBackground(getDrawable(R.drawable.circulos_azules));
            fondo.addView(arraytextviews[i]);
            arraytextviews[i].setText(   ((Character)letras[i]).toString()   );
            arraytextviews[i].setTextColor( Color.WHITE);
            arraytextviews[i].setTextAlignment(View.TEXT_ALIGNMENT_CENTER );
        }

/**
 * INSERTAMOS LA PREGUNTA CORRESPONDIENTE A LA LETRA "A" PARA QUE SALGA DESDE EL PRINCIPIO
 */
        DatabaseReference dbreference = FirebaseDatabase.getInstance().getReference().child("Letras").child("A").child("0").child("pregunta");

        dbreference.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {
                TextView preguntas = (findViewById(R.id.textView4));
                preguntas.setText(dataSnapshot.getValue().toString());

            }

            @Override
            public void onCancelled(DatabaseError databaseError) {
                System.out.println("The read failed: " + databaseError.getCode());
            }});




        //-------------------------------------------------------------------------GENERACION DE LA CAMARA--------------------------------------------------------------------------
/**
 * LAYOUT DE LA CAMARA
 */

        FrameLayout ventanaCamara = findViewById(R.id.frameLayout);


/**
 * SI EL USUARIO ACEPTA LOS PERMISOS, LANZA LA CAMARA
 */

        if (checkPermission()) {
            frameLayout = (FrameLayout)findViewById(R.id.frameLayout);

            //ABRIMOS LA CAMARA
            camera = Camera.open(Camera.CameraInfo.CAMERA_FACING_FRONT);

            //GIRA LA CAMARA 90º PARA PONERLA VERTICAL, YA QUE POR DEFECTO APARECE EN HORIZONTAL
            camera.setDisplayOrientation(90);

            //MOSTRAMOS LA CAMARA
            mostrarCamara = new MostrarCamara(this, camera);
            frameLayout.addView(mostrarCamara);

        } else {
            requestPermission();
        }



        //-------------------------------------------------------------------------CREACION DEL BOTON NEXT--------------------------------------------------------------------------
/**
 *ESTE BOTON VA BUSCANDO LAS LETRAS QUE NO SE HAN CONTESTADO PARA PODER REALIZAR LA FUNCION DE PASAR PALABRA
 */
        Button btn = (Button) findViewById(R.id.botonNext);
        btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {


/**
 * SE CONTROLAN LAS POSICIONES PARA QUE NO SE SALGA DEL ARRAY
 */

                int posicioncontestada;
                if (posicion == 25){
                    posicioncontestada = 0;
                    posicion = 0;
                }
                else{
                    posicioncontestada = 1;
                }

/**
 * BUCLE QUE HACE QUE AVANCE HASTA QUE ENCUENTRE UNA LETRA SIN RESPONDER
 */

                while(arrayrespondido[posicion+posicioncontestada] != 'O'){
                    posicioncontestada++;
                    if (posicion+posicioncontestada == 26){
                        posicion = -posicioncontestada;
                    }
                }
                posicion+=posicioncontestada;

/**
 * OBETENEMOS LAS PREGUNTAS DE LA BASE DE DATOS FIREBASE EN FUNCION DE SU POSICION
 */

                DatabaseReference dbreference = FirebaseDatabase.getInstance().getReference().child("Letras").child(""+letras[posicion]).child("0").child("pregunta");
                dbreference.addValueEventListener(new ValueEventListener() {
                    @Override
                    public void onDataChange(DataSnapshot dataSnapshot) {
/**
 * METEMOS LAS PREGUNTAS EN UN TEXTVIEW
 */

                        TextView preguntas = (findViewById(R.id.textView4));
                        preguntas.setText(dataSnapshot.getValue().toString());

                    }

                    @Override
                    public void onCancelled(DatabaseError databaseError) {
                        System.out.println("The read failed: " + databaseError.getCode());
                    }});
            }
        });


        //-------------------------------------------------------------------------CREACION DEL BOTON SEND--------------------------------------------------------------------------
/**
 * ESTE BOTON OBTIENE LAS PREGUNTAS DE FIREBASE Y LAS COMPARA CON L OQUE INTRODUZCA EL USAURIO, SI ESTA BIEN, PONE UN CIRCULO VERDE EN EL ROSCO, SI ESTA MAL, PONE UN CIRCULO ROJO.
 */

        final EditText et1 = (EditText)findViewById(R.id.textoRespuesta);
        final TextView contfallos = (TextView)findViewById(R.id.Fallos);
        final TextView contaciertos = (TextView)findViewById(R.id.Aciertos);
        contaciertos.setText("Aciertos: "+bien);
        contfallos.setText("Fallos: "+mal);

        Button btn2 = (Button) findViewById(R.id.botonSend);
        btn2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

/**
 * OBTENEMOS TODAS LAS PREGUNTAS DE LA BASE DE DATOS
 */

                DatabaseReference dbreference = FirebaseDatabase.getInstance().getReference().child("Letras").child(""+letras[posicion]).child("0").child("respuesta");
                dbreference.addValueEventListener(new ValueEventListener() {
                    @Override
                    public void onDataChange(DataSnapshot dataSnapshot) {
/**
 * SE COMPARA LA RESPUESTA CON LA DE LA BASE DE DATOS CONVIRTIENDOLA A STRING Y A MINUSCULA, SI ES CORRECTA SUMA 1 AL CONTADOR DE BIEN Y PONE UN CIRCULO VERDE, SI ESTA MAL, PONE CIRCULO ROJO Y SUMA AL CONTADOR DE MAL.
 */

                        if (et1.getText().toString().toLowerCase().equals(dataSnapshot.getValue().toString().toLowerCase())){
                            arrayrespondido[posicion]= 'V'; //V MAYUSCULA SIGNIFICA ACERTADO
                            bien++;
                            contaciertos.setText("Aciertos: "+bien);
                            arraytextviews[posicion].setBackground(getDrawable(R.drawable.circulos_verdes));
                        }
                        else {
                            arrayrespondido[posicion]= 'X'; //X MAYUSCULA SIGNIFICA FALLADO
                            mal++;
                            contfallos.setText("Fallos: "+mal);
                            arraytextviews[posicion].setBackground(getDrawable(R.drawable.circulos_rojos));
                        }

                    }

                    @Override
                    public void onCancelled(DatabaseError databaseError) {
                        System.out.println("The read failed: " + databaseError.getCode());
                    }});

/**
 * SI LOS CONTADORES DE BIEN Y MAL SUMAN EL NUMERO TOTAL DE LETRAS, LLAMA A UN DIALOG QUE TE MUESTRA TUS ESTADISTICAS Y FINALIZA LA ACTIVITY
  */
                if (bien + mal == 25){
                    FragmentManager fragmentManager = getSupportFragmentManager();
                    DialogoAlerta dialogo = new DialogoAlerta();
                    dialogo.show(fragmentManager, "tagAlerta");

                }
            }
        });

/**
 * EJECUTA EL CRONOMETRO
 */
        new ClaseCronometro().execute();


    }

    //-------------------------------------------------------------------------CLASE CRONÓMETRO--------------------------------------------------------------------------
    /**
     * CREAMOS UNA CLASE INTERNA CRONOMETRO CON UN ASYNCTASK QUE VA A REALIZAR LA FUNCION DE CRONOMETRO Y LO VA A IR MOSTRANDO EN UN TEXT VIEW
     */

    private class ClaseCronometro extends AsyncTask<String, Integer, String>{

/**
 * HACE QUE SE PARE EL CRONOMETRO CUANDO EL TOTAL DE RESPUESTAS SEA IGUAL AL NUMERO DE LETRAS
 * @param strings
 * @return
 */

        @Override
        protected String doInBackground(String... strings) {
            while (bien + mal < 26) {
                try {
                    Thread.sleep(1000);
                    segundos++;
                    publishProgress(segundos);

                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
            }
            return "Terminado";
        }

/**
 * ACTUALIZA EL PROGRESO DEL CRONOMETRO EN UN TEXT VIEW
 * @param values
 */

        @Override
        protected void onProgressUpdate(Integer... values) {
            TextView cronometro = (findViewById(R.id.textView2));
            String tiempo = Integer.toString(segundos);
            cronometro.setText(tiempo);

        }

/**
 * MUESTRA EN CONSOLA UN MENSAJE DE TERMINADO
 */

        @Override
        protected void onPostExecute (String s){
            super.onPostExecute(s);
            Log.e("terminado: ", ""+s);
        }
    }

    /**
     * CREAMOS LA CLASE DEL DIALOG
     */
    public static class DialogoAlerta extends DialogFragment {
        @Override
        public Dialog onCreateDialog(Bundle savedInstanceState) {

            AlertDialog.Builder builder =
                    new AlertDialog.Builder(getActivity());

/**
 * MOSTRAMOS EN EL DIALOG LAS ESTADISTICAS Y FINALIZAMOS LA ACTIVITY AL PULSAR OK
 */
            builder.setMessage("Tiempo: "+segundos+" Aciertos: "+ bien+" Errores: "+mal)
                    .setTitle("Tus Estadisticas")
                    .setCancelable(false)
                    .setPositiveButton("¡OK!", new DialogInterface.OnClickListener() {
                        public void onClick(DialogInterface dialog, int id) {
                            dialog.cancel();
                            getActivity().finish();
                        }
                    });

            return builder.create();
        }
    }

    //-------------------------------------------------------------------------------------------------------------------------------------------------------------

/**
 * METODOS QUE PIDEN PERMISOS AL SISTEMA PARA MOSTRAR LA CAMARA Y CONTROLAN LOS POSIBLES ERRORES
 * @return
 */
    private boolean checkPermission() {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA)
                != PackageManager.PERMISSION_GRANTED) {

            return false;
        }
        return true;
    }

    private void requestPermission() {

        ActivityCompat.requestPermissions(this,
                new String[]{Manifest.permission.CAMERA},
                PERMISSION_REQUEST_CODE);
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String permissions[], int[] grantResults) {
        switch (requestCode) {
            case PERMISSION_REQUEST_CODE:
                if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                    Toast.makeText(getApplicationContext(), "Permiso concedido", Toast.LENGTH_SHORT).show();
                } else {
                    Toast.makeText(getApplicationContext(), "Permiso denegado", Toast.LENGTH_SHORT).show();
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                        if (ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA)
                                != PackageManager.PERMISSION_GRANTED) {
                            showMessageOKCancel("Tienes que aceptar los permisos",
                                    new DialogInterface.OnClickListener() {
                                        @Override
                                        public void onClick(DialogInterface dialog, int which) {
                                            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                                                requestPermission();
                                            }
                                        }
                                    });
                        }
                    }
                }
                break;
        }
    }

    private void showMessageOKCancel(String message, DialogInterface.OnClickListener okListener) {
        new AlertDialog.Builder(juego.this)
                .setMessage(message)
                .setPositiveButton("OK", okListener)
                .setNegativeButton("Cancel", null)
                .create()
                .show();
    }
    //----------------------------------------------------------------------------------------------------------------------------------------------------------------------


}
