package com.example.portillo.nextword;

import android.content.Context;
import android.hardware.Camera;
import android.view.SurfaceHolder;
import android.view.SurfaceView;

import java.io.IOException;

/**
 * CLASE QUE GENERA LA CAMARA
 */

public class MostrarCamara extends SurfaceView implements SurfaceHolder.Callback{
    Camera camera;
    SurfaceHolder holder;

    public MostrarCamara(Context context, Camera camera) {
        super(context);
        this.camera = camera;
        holder = getHolder();
        holder.addCallback(this);
    }

/**
 * CREA LA SURFACE QUE VA A ACTUAR UNICAMENTE COMO ESPEJO
 * @param holder
 */
    @Override
    public void surfaceCreated(SurfaceHolder holder) {
        Camera.Parameters params = camera.getParameters();
        camera.setParameters(params);
        try {
            camera.setPreviewDisplay(holder);
            camera.startPreview();
        } catch (IOException e){
            e.printStackTrace();
        }
    }


    @Override
    public void surfaceChanged(SurfaceHolder holder, int format, int width, int height) {

    }

    @Override
    public void surfaceDestroyed(SurfaceHolder holder) {

    }

}

