package com.example.portillo.nextword;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

public class BD extends SQLiteOpenHelper {


    public BD(Context context, String name, SQLiteDatabase.CursorFactory factory, int version) {
        super(context, "DataBaase.bd", null, 1);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL("Create table Preguntas(Pregunta text primary key, Respuesta text)");
        db.execSQL("Create table Puntuaciones(Nombre text primary key, Puntos integer, Tiempo integer, Aciertos integer, Errores integer)");
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("drop table if exists Preguntas");
        db.execSQL("drop table if exists Puntuaciones");
    }
}
