package com.example.portillo.nextword;

import android.content.Context;
import android.hardware.Camera;
import android.view.SurfaceHolder;
import android.view.SurfaceView;

import java.io.IOException;

public class MostrarCamara extends SurfaceView implements SurfaceHolder.Callback{
    Camera camera;
    SurfaceHolder holder;

    public MostrarCamara(Context context, Camera camera) {
        super(context);
        this.camera = camera;
        holder = getHolder();
        holder.addCallback(this);
    }

    //CREA LA SURFACE PARA QUE LA CÁMARA ACTUE COMO ESPEJO Y NO HAGA NADA MÁS
    @Override
    public void surfaceCreated(SurfaceHolder holder) {
        Camera.Parameters params = camera.getParameters();
        camera.setParameters(params);
        try {
            camera.setPreviewDisplay(holder);
            camera.startPreview();
        } catch (IOException e){
            e.printStackTrace();
        }
    }

    //SE CONTROLAN LOS ERRORES
    @Override
    public void surfaceChanged(SurfaceHolder holder, int format, int width, int height) {

    }

    @Override
    public void surfaceDestroyed(SurfaceHolder holder) {

    }

}

