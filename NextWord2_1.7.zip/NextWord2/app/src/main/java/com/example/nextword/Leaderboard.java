package com.example.nextword;

import android.content.Intent;
import android.graphics.Color;
import android.support.annotation.NonNull;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.TextView;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.Query;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;
import java.util.List;

public class Leaderboard extends AppCompatActivity {


    //region variables

    TextView tiempo;
    TextView aciertos;
    TextView fallos;
    TextView puntos;
    ImageView imgview;
    ListView lv;
    List <String> lista = new ArrayList<>();
    ArrayAdapter<String> adapter;
    int contador_top;
    Top[] t;


    //endregion

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_leaderboard);
        
        inicializaciones();

        obtenerTop20();

         //hace que puedas pulsar sobre los items del listview
        lv.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {

                //parent.getChildAt(position).setBackgroundResource(R.color.morado);

                //introduce cas caracteristicas del item seleccionado en los textviews
                tiempo.setText(t[Math.abs(position-contador_top+1)].getTiempo());
                aciertos.setText(t[Math.abs(position-contador_top+1)].getAciertos());
                fallos.setText(t[Math.abs(position-contador_top+1)].getFallos());
                puntos.setText(t[Math.abs(position-contador_top+1)].getPuntuacion()+"");
            }
        });
    }

    //region botones

    /**
     * te llava a la pantalla de inicio
     * @param v view
     */
    public void inicioOnClick(View v){
        inicio();
    }

    @Override
    public void onBackPressed() {
        finish();
    }


    //endregion

    //region métodos de los botones

    /**
     * crea el intent hacia la pantalla de inicio
     */
    private void inicio(){
        Intent intent = new Intent(Leaderboard.this, Inicio.class);
        startActivityForResult(intent, 0);
    }


    //endregion

    //region metodos

    /**
     * método que inicializa las variables
     */
    private void inicializaciones(){
        tiempo = findViewById(R.id.leaderboard_tiempo);
        aciertos = findViewById(R.id.leaderboard_aciertos);
        fallos = findViewById(R.id.leaderboard_fallos);
        puntos = findViewById(R.id.leaderboard_puntuacion);
        imgview = findViewById(R.id.imageView);
        lv = findViewById(R.id.listview);
        t = new Top[20];

    }

    /**
     * método que define la lógica del leaderboard
     */
    private void obtenerTop20(){
        DatabaseReference dbreference = FirebaseDatabase.getInstance().getReference().child("Usuarios");

        Query query = dbreference.orderByChild("puntuacion").limitToLast(20);

        query.addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {

                //obtiene los valores de la base de datos y los introduce en un objeto de la clase Top
                contador_top = 0;
                for(DataSnapshot ds : dataSnapshot.getChildren()){
                    t[contador_top] = ds.getValue(Top.class);
                    contador_top++;
                }

                //introduce en la lista la posición del leaderboard y su nombre
                int num = 1;
                for (int j = contador_top -1 ; j >= 0; j--, num++) {
                    lista.add(num + ". " + t[j].getNombre());
                }

                //definimos en el adapter los parametros de las views de la lista
                adapter = new ArrayAdapter<String>(Leaderboard.this,android.R.layout.simple_list_item_1, lista){
                    @Override
                    public View getView(int position, View convertView, ViewGroup parent) {
                        View view=super.getView(position, convertView, parent);

                        TextView textView=(TextView) view.findViewById(android.R.id.text1);

                        textView.setTextColor(Color.WHITE);

                        return view;
                    }
                };

                //asignamos el adapter a un listview
                lv.setAdapter(adapter);

            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });
    }


    //endregion

}
