package com.example.nextword;

/**
 * clase modelo para los objetos del leaderboard
 */
public class Top {
    private String nombre;
    private String tiempo;
    private String aciertos;
    private String fallos;
    private int puntuacion;

    public Top() {
    }


    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getTiempo() {
        return tiempo;
    }

    public void setTiempo(String tiempo) {
        this.tiempo = tiempo;
    }

    public String getAciertos() {
        return aciertos;
    }

    public void setAciertos(String aciertos) {
        this.aciertos = aciertos;
    }

    public String getFallos() {
        return fallos;
    }

    public void setFallos(String fallos) {
        this.fallos = fallos;
    }

    public int getPuntuacion() {
        return puntuacion;
    }

    public void setPuntuacion(int puntuacion) {
        this.puntuacion = puntuacion;
    }

    @Override
    public String toString() {
        return "Top{" +
                "nombre='" + nombre + '\'' +
                ", tiempo='" + tiempo + '\'' +
                ", aciertos='" + aciertos + '\'' +
                ", fallos='" + fallos + '\'' +
                ", puntuacion='" + puntuacion + '\'' +
                '}';
    }
}
